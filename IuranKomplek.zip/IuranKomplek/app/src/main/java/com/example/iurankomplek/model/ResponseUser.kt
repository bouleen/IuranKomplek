package com.example.iurankomplek.model

data class ResponseUser(val data: List<DataItem>)
